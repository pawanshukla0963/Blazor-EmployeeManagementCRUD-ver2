﻿using AutoMapper;
using EmployeeeManagement.Web.Models;
using EmployeeeManagement.Web.Services;
using EmployeeManagement;
using EmployeeManagement.Models;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeeManagement.Web.Pages
{
    public class EditEmployeeBase : ComponentBase
    {
        [Inject]
        public IEmployeeService EmployeeService { get; set; }       //to retrieve emp data

        private Employee Employee { get; set; } = new Employee();        //to hold emp data fetched via api

        public EditEmployeeModel EditEmployeeModel { get; set; } = new EditEmployeeModel();

        [Inject]
        public IDepartmentService DepartmentService { get; set; }

        public List<Department> Departments { get; set; } = new List<Department>();

        public string DepartmentId { get; set; }      // guid is guid

        [Parameter]
        public string Id { get; set; }      //id will be passed in url

        [Inject]
        public IMapper Mapper { get; set; }     //injecting automapper service in component classi.e this file & decorating by inject attr.

        [Inject]
        public NavigationManager NavigationManager { get; set; }
        protected async override Task OnInitializedAsync()
        {
            int.TryParse(Id, out int employeeId);       //to convert id strign to injt
            if (employeeId!=0)      //check 0 since eid is for both updte and create
            {
                Employee = await EmployeeService.GetEmployee(int.Parse(Id));
            }
            else
            {
                Employee = new Employee
                {
                    DepartmentId = 1,
                    DateOfBirth = DateTime.Now,
                    PhotoPath = "images/nophoto.jpg"
                };
            }
            //calling REST API and retrieve emp data
            //Employee = await EmployeeService.GetEmployee(int.Parse(Id));
            Departments = (await DepartmentService.GetDepartments()).ToList();
            //DepartmentId = Employee.DepartmentId.ToString();
            //DepartmentId = Guid.NewGuid();
            Mapper.Map(Employee, EditEmployeeModel);

        }

        protected async Task HandleValidSubmit() {
            Mapper.Map(EditEmployeeModel, Employee);

            Employee result = null;
            if (Employee.EmployeeId!=0)
            {
                result = await EmployeeService.UpdateEmployee(Employee);
            }
            else
            {
                result = await EmployeeService.CreateEmployee(Employee);
            }

            //var result = await EmployeeService.UpdateEmployee(Employee);
            if (result != null) {
                NavigationManager.NavigateTo("/");      //if update successful,redirect user to list / means emp root url
            }
        }

        protected async Task Delete_Click() {
            await EmployeeService.DeleteEmployee(Employee.EmployeeId);
            NavigationManager.NavigateTo("/");
        }
    }
}
