﻿using EmployeeeManagement.Web.Services;
using EmployeeManagement;
using EmployeeManagement.Models;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeeManagement.Web.Pages
{
    public class EmployeeListBase : ComponentBase
    {
        [Inject]
        public IEmployeeService EmployeeService { get; set; }

        public bool ShowFooter { get; set; } = true; 
        public IEnumerable<Employee> Employees { get; set; }
        protected override async Task OnInitializedAsync()
        {
            Employees=(await EmployeeService.GetEmployees()).ToList();
          // await Task.Run(LoadEmployees);
            //return base.OnInitializedAsync();
        }

        protected int SelectedEmployeesCount { get; set; } = 0;

        protected void EmployeeSelectionChanged(bool isSelected) {
            if (isSelected) {
                SelectedEmployeesCount++;
            }
            else
            {
                SelectedEmployeesCount--;
            }
        }

        /*private void LoadEmployees() {            //sent to bin
            System.Threading.Thread.Sleep(3000);
            Employee e1 = new Employee{
                EmployeeId=1,
                FirstName="Johny",
                LastName="Hastinger",
                Email="jher@abc.com",
                DateOfBirth=new DateTime(1980,11,1),
                Gender=Gender.Male,
                DepartmentId=1,
                PhotoPath="images/emp1.jpg"
            };
            Employee e2 = new Employee
            {
                EmployeeId = 2,
                FirstName = "Johniie",
                LastName = "Hastingo",
                Email = "jho@abc.com",
                DateOfBirth = new DateTime(1980, 1, 2),
                Gender = Gender.Male,
                DepartmentId = 2,
                PhotoPath = "images/emp2.jpg"
            };
            Employee e3 = new Employee
            {
                EmployeeId = 3,
                FirstName = "Johndoe",
                LastName = "Hastingerry",
                Email = "jhdo@abc.com",
                DateOfBirth = new DateTime(1980, 12, 4),
                Gender = Gender.Male,
                DepartmentId = 3,
                PhotoPath = "images/emp3.jpg"
            };
            Employee e4 = new Employee
            {
                EmployeeId = 4,
                FirstName = "John",
                LastName = "Hasting",
                Email = "jh@abc.com",
                DateOfBirth = new DateTime(1980, 12, 4),
                Gender = Gender.Male,
                DepartmentId = 1,
                PhotoPath = "images/emp4.jpg"
            };
            Employees = new List<Employee> {e1,e2,e3,e4 };
        }*/
    }
}
